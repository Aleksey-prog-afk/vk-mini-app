self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9ce202cdaf58eea0183727c3871e225d",
    "url": "/index.html"
  },
  {
    "revision": "9d42223d7d985fcc2509",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "fc822cdae69d741e187b",
    "url": "/static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "9d42223d7d985fcc2509",
    "url": "/static/js/2.e02348a1.chunk.js"
  },
  {
    "revision": "f4d96dcd2d9856e558b9594520c0fd05",
    "url": "/static/js/2.e02348a1.chunk.js.LICENSE.txt"
  },
  {
    "revision": "fc822cdae69d741e187b",
    "url": "/static/js/main.0a2c7b92.chunk.js"
  },
  {
    "revision": "d5d50483e52d53a4b219",
    "url": "/static/js/runtime-main.29d8161a.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);